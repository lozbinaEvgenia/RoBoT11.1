﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РОБОТ_ИГРА
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            robot robot1 = new robot();
            robot robot2 = new robot();
            robot robot3 = new robot();
            Random rn = new Random();
            if (double.TryParse(textBox1.Text, out double r))
            {
                if (r < 0)
                {
                    MessageBox.Show("Введите положительное число", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                }
            }
            if (double.TryParse(textBox2.Text, out double r1))
            {
                if (r1 < 0)
                {
                    MessageBox.Show("Введите положительное число", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                    label3.Text = "";
                    label4.Text = "";
                }
            }
            if (double.TryParse(textBox3.Text, out double r3))
            {
                if (r3 < 0)
                {
                    MessageBox.Show("Введите положительное число", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                    label5.Text = "";
                    label6.Text = "";
                }
            }
            if (textBox1.Text != "")
            {
                int b = rn.Next(0, 100);
                robot1.min(b);
            }
            if (textBox1.Text == "")
            {
                label1.Text = "Поле не заполнено";
                label2.Text = "";
            }
            else if (r < 0)
            {
                label1.Text = "";
                label2.Text = "";
            }

            else
            {
                robot1.kollife = Convert.ToInt32(textBox1.Text);
                label1.Text = " Количество жизней робота1 в начале игры " + robot1.kollife;

            }
            if (textBox2.Text == "")
            {
                label3.Text = "Поле не заполнено";
                label4.Text = "";
            }
            else if (r1 < 0)
            {
                label3.Text = "";
                label4.Text = "";
            }

            else
            {
                robot2.kollife = Convert.ToInt32(textBox2.Text);
                label3.Text = " Количество жизней робота2 в начале игры " + robot2.kollife;

            }
            if (textBox3.Text == "")
            {
                label5.Text = "Поле не заполнено";
                label6.Text = "";
            }
            else if (r3 < 0)
            {
                label5.Text = "";
                label6.Text = "";
            }
            else
            {
                robot3.kollife = Convert.ToInt32(textBox3.Text);
                label5.Text = "  Количество жизней робота3 в начале игры " + robot3.kollife;

            }
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && r > 0 && r1 > 0 && r3 > 0)
            {
                int a = robot1.kollife;
                robot1.min(robot1.kollife);
                label2.Text = " Количество жизней робота1 в конце игры " + Convert.ToString(robot1.getlife());
                robot2.kol(a, robot1.kollife);
                label4.Text = " Количество жизней робота2 в конце игры " + Convert.ToString(robot2.getlife());
                robot3.kol(a, robot1.kollife);
                label6.Text = " Количество жизней робота3 в конце игры " + Convert.ToString(robot3.getlife());
            }
        }
    }
}
